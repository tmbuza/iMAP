representative.sh in=results_ani94_sr00_wkid.txt thresh=0.95 minratio=0.95 out=rep_95_95.txt ow -Xmx31g
representative.sh in=results_ani94_sr00_wkid.txt thresh=0.97 minratio=0.97 out=rep_97_97.txt ow -Xmx31g
representative.sh in=results_ani94_sr00_wkid.txt thresh=0.98 minratio=0.98 out=rep_98_98.txt ow -Xmx31g
representative.sh in=results_ani94_sr00_wkid.txt thresh=0.99 minratio=0.99 out=rep_99_99.txt ow -Xmx31g
representative.sh in=results_ani94_sr00_wkid.txt thresh=0.995 minratio=0.995 out=rep_995_995.txt ow -Xmx31g
representative.sh in=results_ani94_sr00_wkid.txt thresh=0.999 minratio=0.999 out=rep_999_999.txt ow -Xmx31g
