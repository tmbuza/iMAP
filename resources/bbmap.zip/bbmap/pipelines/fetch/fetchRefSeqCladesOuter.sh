nohup sh fetchRefSeqClades.sh
