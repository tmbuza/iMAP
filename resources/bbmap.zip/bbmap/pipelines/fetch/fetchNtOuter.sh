nohup time sh fetchNt.sh
